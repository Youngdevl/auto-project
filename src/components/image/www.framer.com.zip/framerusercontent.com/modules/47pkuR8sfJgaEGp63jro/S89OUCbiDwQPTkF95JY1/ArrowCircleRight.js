let Component;
var ArrowCircleRight_default = (React) => {
    if (!Component) {
        const renderPathForWeight = (weight, color, pathsByWeight2) => !!pathsByWeight2.get(weight) ? pathsByWeight2.get(weight)(color) : null;
        const pathsByWeight = new Map();
        pathsByWeight.set("bold", (color) => /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("circle", {
            cx: "128",
            cy: "128",
            r: "96",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "24"
        }), /* @__PURE__ */ React.createElement("polyline", {
            points: "134.1 161.9 168 128 134.1 94.1",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "24"
        }), /* @__PURE__ */ React.createElement("line", {
            x1: "88",
            y1: "128",
            x2: "168",
            y2: "128",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "24"
        })));
        pathsByWeight.set("duotone", (color) => /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("circle", {
            cx: "128",
            cy: "128",
            r: "96",
            opacity: "0.2"
        }), /* @__PURE__ */ React.createElement("circle", {
            cx: "128",
            cy: "128",
            r: "96",
            fill: "none",
            stroke: color,
            strokeMiterlimit: "10",
            strokeWidth: "16"
        }), /* @__PURE__ */ React.createElement("polyline", {
            points: "134.1 161.9 168 128 134.1 94.1",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "16"
        }), /* @__PURE__ */ React.createElement("line", {
            x1: "88",
            y1: "128",
            x2: "168",
            y2: "128",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "16"
        })));
        pathsByWeight.set("fill", () => /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("path", {
            d: "M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm47.4,107.1a8.7,8.7,0,0,1-1.8,2.6l-33.9,33.9a7.6,7.6,0,0,1-5.6,2.3,7.8,7.8,0,0,1-5.7-2.3,8,8,0,0,1,0-11.3L148.7,136H88a8,8,0,0,1,0-16h60.7L128.4,99.7a8,8,0,0,1,11.3-11.3l33.9,33.9a8.7,8.7,0,0,1,1.8,2.6A8.3,8.3,0,0,1,175.4,131.1Z"
        })));
        pathsByWeight.set("light", (color) => /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("circle", {
            cx: "128",
            cy: "128",
            r: "96",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "12"
        }), /* @__PURE__ */ React.createElement("polyline", {
            points: "134.1 161.9 168 128 134.1 94.1",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "12"
        }), /* @__PURE__ */ React.createElement("line", {
            x1: "88",
            y1: "128",
            x2: "168",
            y2: "128",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "12"
        })));
        pathsByWeight.set("thin", (color) => /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("circle", {
            cx: "128",
            cy: "128",
            r: "96",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "8"
        }), /* @__PURE__ */ React.createElement("polyline", {
            points: "134.1 161.9 168 128 134.1 94.1",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "8"
        }), /* @__PURE__ */ React.createElement("line", {
            x1: "88",
            y1: "128",
            x2: "168",
            y2: "128",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "8"
        })));
        pathsByWeight.set("regular", (color) => /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("circle", {
            cx: "128",
            cy: "128",
            r: "96",
            fill: "none",
            stroke: color,
            strokeMiterlimit: "10",
            strokeWidth: "16"
        }), /* @__PURE__ */ React.createElement("polyline", {
            points: "134.1 161.9 168 128 134.1 94.1",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "16"
        }), /* @__PURE__ */ React.createElement("line", {
            x1: "88",
            y1: "128",
            x2: "168",
            y2: "128",
            fill: "none",
            stroke: color,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "16"
        })));
        const renderPath = (weight, color) => renderPathForWeight(weight, color, pathsByWeight);
        const ArrowCircleRight = React.forwardRef((props, ref) => /* @__PURE__ */ React.createElement("g", {
            ref,
            ...props
        }, renderPath(props.weight, props.color)));
        ArrowCircleRight.displayName = "ArrowCircleRight";
        Component = ArrowCircleRight;
    }
    return Component;
};
const __FramerMetadata__ = {
    exports: {
        default: {
            type: "reactComponent",
            slots: [],
            annotations: {
                framerContractVersion: "1"
            }
        },
        __FramerMetadata__: {
            type: "variable"
        }
    }
};
export {
    __FramerMetadata__,
    ArrowCircleRight_default as
    default
};