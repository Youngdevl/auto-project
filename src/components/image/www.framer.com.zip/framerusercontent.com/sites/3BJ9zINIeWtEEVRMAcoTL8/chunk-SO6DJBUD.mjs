import{a as s}from"./chunk-KPQHOKQ2.mjs";import{b as o}from"./chunk-CG37XTOU.mjs";import{ta as e}from"./chunk-RQHFLBZ5.mjs";import{f as r}from"./chunk-ENK4YSX5.mjs";r();var n=[`
  strong {
      font-weight: normal;
      background-color: #eee;
      background: linear-gradient(180deg, rgba(248,248,248, 1) 0%, rgba(238,238,238, 1) 100%);
      padding: 4px 7px 4px 5px;
      border-radius: 8px;
      text-shadow: 0 1px 0 rgba(255,255,255, 0.5);
      box-shadow: 
        inset 0 2px 0 rgba(255,255,255,0.4), 
        inset 0 -2px 0 rgba(0,0,0,0.05), 
        inset 0 0 0 1px rgba(0,0,0,0.08);
  }
`];function b(p){let t=`keycaps-${s(n.toString())}`,i=n.map(a=>`.${t} ${a}`),c=e(p,i);return a=>o(c,{...a,className:`${a.className} ${t}`})}export{b as a};
//# sourceMappingURL=chunk-SO6DJBUD.mjs.map
