import{f as t}from"./chunk-ENK4YSX5.mjs";t();var n=e=>typeof e=="string"?e:String(e),o=e=>({bodyClassName:"framer-body-Imw0RltQ2",breakpoints:[{hash:"11sefo9",mediaQuery:"(min-width: 1200px)"},{hash:"qt2r39",mediaQuery:"(min-width: 810px) and (max-width: 1199px)"},{hash:"hhphue",mediaQuery:"(max-width: 809px)"}],customHTMLHeadEnd:`<style>
    html { scroll-behavior: smooth;}
    @media (prefers-reduced-motion) {
        html { scroll-behaviour: auto; }
    }
</style>`,description:`${e?.pFO9tTGs4!==void 0?n(e.pFO9tTGs4):"{{pFO9tTGs4}}"}`,elements:{},socialImage:new URL("https://framerusercontent.com/images/ZSvRqaYRHbzPwDjXhmKH4zmw.jpg").href,title:`Framer: ${e?.uDZV5jGg_!==void 0?n(e.uDZV5jGg_):"{{uDZV5jGg_}}"}`,viewport:"width=device-width"}),r=o,a=1,i={exports:{metadataVersion:{type:"variable",annotations:{framerContractVersion:"1"}},default:{type:"variable",annotations:{framerContractVersion:"1"}},__FramerMetadata__:{type:"variable"}}};export{r as a,a as b,i as c};
//# sourceMappingURL=chunk-RLM7NTRS.mjs.map
