import{b as n}from"./chunk-CG37XTOU.mjs";import{f as i}from"./chunk-ENK4YSX5.mjs";i();function a(e){return t=>n(e,{...t,style:{...t.style,zIndex:100}})}function o(e){return t=>n(e,{...t,layout:"position",transition:{layout:{type:!1}}})}export{a,o as b};
//# sourceMappingURL=chunk-KCBLHZSN.mjs.map
