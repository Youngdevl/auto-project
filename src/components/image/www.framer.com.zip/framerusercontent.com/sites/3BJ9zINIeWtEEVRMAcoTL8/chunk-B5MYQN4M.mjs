import{f as e}from"./chunk-ENK4YSX5.mjs";e();var a=t=>({customHTMLBodyStart:`<!-- Used by Page.tsx to initialize Google One Tap Authentication -->
            <div id="g_id_onload" data-login_uri="https://www.framer.com/api-proxy/auth-google-one-tap-callback" data-client_id="494526493439-djlkk2cal7r0lijnrd6en51c9vo4icgp.apps.googleusercontent.com" data-state_cookie_domain="framer.com" data-auto_prompt="false" data-prompt_parent_id="__framer-flap" data-cancel_on_tap_outside="false" data-itp_support="true"></div>`,customHTMLHeadEnd:`<!-- Google Tag Manager -->
<script async="">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KQFN6BX');<\/script>
<!-- End Google Tag Manager -->

<!-- Google Search Console -->
<meta name="google-site-verification" content="srewg7cpiErKYvspydAuj9hVuvnpDkL6-xS2Zrm0DNY">

<!-- Google One Tap -->
<script defer="" async="" src="https://accounts.google.com/gsi/client" type="text/javascript"><\/script>

<!-- Pinterest -->
<meta name="p:domain_verify" content="baa2b7609d30ac861f0cdfbae1835029">`,description:"Design your website on a familiar canvas. Add animations, interactions and a CMS. Optimize for every breakpoint \u2014 no code needed and publish for free.",favicon:new URL("https://framerusercontent.com/images/3ydDYhTbVKKzF5xDzZpZKoMmc.png").href,socialImage:new URL("https://framerusercontent.com/images/eeQxQigtp2udr978UeSlCsWAI.jpg").href,title:"Framer \u2014  Design and ship your dream site. Zero code, maximum speed."}),n=a;export{n as a};
//# sourceMappingURL=chunk-B5MYQN4M.mjs.map
