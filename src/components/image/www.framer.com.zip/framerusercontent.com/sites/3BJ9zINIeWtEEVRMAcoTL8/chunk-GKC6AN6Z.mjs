import{f as e}from"./chunk-ENK4YSX5.mjs";e();var a=r=>({bodyClassName:"framer-body-k_d8t7k9Z",breakpoints:[{hash:"licprj",mediaQuery:"(min-width: 1200px)"},{hash:"fd81rs",mediaQuery:"(min-width: 610px) and (max-width: 1199px)"},{hash:"bpi3mq",mediaQuery:"(max-width: 609px)"}],customHTMLHeadEnd:`<style>
    html { scroll-behavior: smooth;}
    @media (prefers-reduced-motion) {
        html { scroll-behaviour: auto; }
    }
</style>`,description:"Become a verified Framer partner and start earning money from your creative work or find the best Framer pros in our partner channel on our Discord.",elements:{QtUh4JjRW:"program",XhI3OlvB6:"apply"},socialImage:new URL("https://framerusercontent.com/images/V8sWbsz08qshIIVTq0CAANMa1lM.jpg").href,title:"Framer Partners",viewport:"width=device-width"}),t=a,o=1,n={exports:{default:{type:"variable",annotations:{framerContractVersion:"1"}},metadataVersion:{type:"variable",annotations:{framerContractVersion:"1"}},__FramerMetadata__:{type:"variable"}}};export{t as a,o as b,n as c};
//# sourceMappingURL=chunk-GKC6AN6Z.mjs.map
