import{f as t}from"./chunk-ENK4YSX5.mjs";t();
//# sourceMappingURL=chunk-2U2EFFDD.mjs.map
